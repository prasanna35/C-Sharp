﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CustomerFileUsingStreamwriterAndStreamReader
{
    public class Customer
    {
        public class BankAccount
        {
            public string Name;
            public double AccountNumber;
            public double balance;

            public BankAccount(string name, double accountnumber, double balance)
            {
                this.Name = name;
                this.AccountNumber = accountnumber;
                this.balance = balance;
            }
        }
        static void Main(string[] args)
        {

            string dir = @"C:\Sailu\BankAccountDetails";
            string srcFilepath = @"C:\Sailu\BankAccountDetails\AccountDetails.txt";
            Directory.CreateDirectory(dir);

            
            FileStream fs = File.Create(srcFilepath);
            fs.Close();
            Console.WriteLine("Enter AccountHolder Name :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Account Number :");
            double accountNumber = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Account Balance :");
            double balance = double.Parse(Console.ReadLine());
            BankAccount ba = new BankAccount(name, accountNumber, balance);

            StreamWriter sw = new StreamWriter(srcFilepath);
            sw.WriteLine(ba.Name);
            sw.WriteLine(ba.AccountNumber);
            sw.WriteLine(ba.balance);

            sw.Close();

            
            StreamReader sr = new StreamReader(srcFilepath);
            string line;

            Console.WriteLine("\nAccounts Details :");
            while ((line = sr.ReadLine()) != null)
            {

                Console.WriteLine(line);
            }

            Console.ReadLine();
        }
    }
}
