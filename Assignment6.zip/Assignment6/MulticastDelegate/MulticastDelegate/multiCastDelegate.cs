﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    class multiCastDelegate
    {
        public class Employee
        {
            protected int EmpNo;
            protected string EmpName;
            protected double Salary;
            protected double HRA;
            protected double TA;
            protected double DA;
            protected double PF;
            protected double TDS;
            protected double NetSalary;
            protected double GrossSalary;

            public void SetEmpNo(int EmpNo)
            {
                this.EmpNo = EmpNo;
            }
            public void SetEmpName(string EmpName)
            {
                this.EmpName = EmpName;
            }
            public double SetSalary(double Salary)
            {
                this.Salary = Salary;
                if (this.Salary < 500)
                {
                    this.HRA = (this.Salary * 10) / 100;
                    this.TA = (this.Salary * 5) / 100;
                    this.DA = (this.Salary * 15) / 100;
                }
                else if (this.Salary > 5000 && this.Salary < 10000)
                {
                    this.HRA = (this.Salary * 15) / 100;
                    this.TA = (this.Salary * 10) / 100;
                    this.DA = (this.Salary * 20) / 100;
                }
                else if (this.Salary >= 10000 && this.Salary < 15000)
                {
                    this.HRA = (this.Salary * 20) / 100;
                    this.TA = (this.Salary * 15) / 100;
                    this.DA = (this.Salary * 25) / 100;
                }
                else if (this.Salary >= 15000 && this.Salary < 20000)
                {
                    this.HRA = (this.Salary * 25) / 100;
                    this.TA = (this.Salary * 20) / 100;
                    this.DA = (this.Salary * 30) / 100;
                }
                else
                {
                    this.HRA = (this.Salary * 30) / 100;
                    this.TA = (this.Salary * 25) / 100;
                    this.DA = (this.Salary * 35) / 100;
                }
                //Gross Salary
                return this.GrossSalary = this.Salary + this.HRA + this.TA + this.DA;

            }
            
            public virtual double CalculateSalary()
            {
                this.PF = (this.GrossSalary * 10) / 100;
                this.TDS = (this.GrossSalary * 18) / 100;
                this.NetSalary = this.GrossSalary - (this.PF + this.TDS);
                return this.NetSalary;
            }
            
        }

        
        public class Manager : Employee
        {
            
            public delegate double EmployeeDelegate();

            private double PetrolAllowance;
            private double FoodAllowance;
            private double OtherAllowances;

            public double SetSalary(double Salary)
            {
                base.SetSalary(Salary);
                this.PetrolAllowance = Salary * 8 / 100;
                this.FoodAllowance = Salary * 13 / 100;
                this.OtherAllowances = Salary * 3 / 100;
                return this.GrossSalary = base.GrossSalary + PetrolAllowance + FoodAllowance + OtherAllowances;
            }
            public override double CalculateSalary()
            {
                TDS = GrossSalary * 18 / 100;
                NetSalary = GrossSalary - TDS;
                return NetSalary;

            }
        }
        
        class MarketingExecutive : Employee
        {
            
            public delegate double EmployeeDelegate1();

            private double KilometerTravel;
            private double TourAllowances;
            private int TelephoneAllowances = 1000;

            
            public void SetKilometersTravel(double Kilo)
            {
                KilometerTravel = Kilo;
                TourAllowances = KilometerTravel * 5;
            }
            public double SetSalary(double Salary)
            {
                base.SetSalary(Salary);
                return GrossSalary += TourAllowances + TelephoneAllowances;
            }
            
            public override double CalculateSalary()
            {
                TDS = GrossSalary * 18 / 100;
                NetSalary = GrossSalary - TDS;
                return NetSalary;

            }
        }
        static void Main(string[] args)
        {
            
            Console.Write("Enter Employee ID: ");
            int EmpId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee NAME: ");
            string EmpName = Console.ReadLine();
            Console.Write("Enter Employee SALARY: ");
            double Salary = double.Parse(Console.ReadLine());
            Console.Write("Enter kilometre value :");
            int kilo1 = Convert.ToInt32(Console.ReadLine());


            

            Employee employee = new Employee();
            employee.SetEmpNo(EmpId);
            employee.SetEmpName(EmpName);
            employee.SetSalary(Salary);
            employee.CalculateSalary();

            

            Manager manager = new Manager();
            manager.SetSalary(Salary);


           

            MarketingExecutive me = new MarketingExecutive();
            me.SetSalary(Salary);
            me.SetKilometersTravel(kilo1);

            Console.WriteLine("\n------------------------\n");
            Console.WriteLine("Manager Gross Salary is :{0}", manager.SetSalary(Salary));
            Console.WriteLine("MarketingExecutive Gross Salary is :{0}\n", me.SetSalary(Salary));


            
            Manager.EmployeeDelegate del = new Manager.EmployeeDelegate(manager.CalculateSalary);
            MarketingExecutive.EmployeeDelegate1 del1 = new MarketingExecutive.EmployeeDelegate1(me.CalculateSalary);

            Console.WriteLine("Manager Net Salary is : " + del());
            Console.WriteLine("MarketingExecutive Net Salary is : " + del1());
            Console.ReadKey();
        }
    }
}
