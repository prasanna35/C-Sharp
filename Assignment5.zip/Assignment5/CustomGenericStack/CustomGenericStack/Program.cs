﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomGenericStack
{
    class MyStack
    {
        public static void Main()
        {
            Stack<string> numbers = new Stack<string>();
            numbers.Push("one");
            numbers.Push("two");
            numbers.Push("three");
            numbers.Push("four");
            numbers.Push("five");

            foreach (string number in numbers)
            {
                Console.WriteLine(number);
            }

            numbers.Pop();

            Console.WriteLine("After popping all the elements in the stack are : ");

            foreach (string number in numbers)
            {
                Console.WriteLine(number);
            }



        }
    }
}