﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    public class Arrays
    {
        static void Main(string[] args)
        {
           
            int[] arr1 = new int[5] {6,3,8,2,1 };
             
            int[] arr2 = new int[5];
            
            Console.WriteLine("length of first array: " + arr1.Length);
             
            Array.Sort(arr1);
            Console.Write("\n------------------------------------\n");
            Console.Write("array 1 elements: ");
            
            PrintArray(arr1);
         
            Array.Copy(arr1, arr2, arr1.Length);
            Console.Write("array 2 elements: ");
            PrintArray(arr2);
            Console.Write("\n------------------------------------\n");

            Array.Reverse(arr1);
            Console.Write("\n Array 1 elements in reverse order: ");
            PrintArray(arr1);

            Console.Write("\n------------------------------------\n");
            Console.Write("After clearing Array 1 is");
            Array.Clear(arr1, 0, arr1.Length);
            Console.Write(" First Array length is", arr1.Length);
        }
        
        static void PrintArray(int[] arr1)
        {
            foreach (int val in arr1)
            {
                Console.Write(val + " ");
            }
        }
    }
}
