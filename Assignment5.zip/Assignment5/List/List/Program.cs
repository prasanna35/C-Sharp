﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
   public class program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            list.Add("Shekhar");
            list.Add("Kamal");
            list.Add("Roja");
            list.Add("Teja");
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("List of all employees" + ':' + list[i]);
            }
            Console.WriteLine("Total number of employess" + ':' + list.Count);
            Console.ReadLine();
        }
    }
}
