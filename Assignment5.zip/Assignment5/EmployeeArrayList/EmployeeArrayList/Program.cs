﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeArrayList
{
    public class EmpArrayList
    {
        static void Main(string[] args)
        { 
            int size;
            Console.WriteLine("Enter total number of employees");
            size = int.Parse(Console.ReadLine());
            ArrayList al = new ArrayList(size);  
            int empId = 0;
            Console.WriteLine("Enter the Empid to view all Employees Details");
            String adminUserId = Console.ReadLine();
            String empName1 = "Shekhar";
            String emp1Designation = "Developer";
           
            al.Add(empName1 + " : " + emp1Designation);
           

            String empName2 = "Rajput";
            String emp2Designation ="Trainer";
            al.Add(empName2 + " : " + emp2Designation);
            

            String empName3 = "Shiva";
            String emp3Designation = "Analyst";
            al.Add(empName3 + " : " + emp3Designation);
            

            String empName4 = "Kunal";
            String emp4Designation = "Software Engineer";
            al.Add(empName4 + " : " + emp4Designation);
           

            String empName5 = "Pravallika";
            String emp5Designation = "Software Engineer"; 
            al.Add(empName5 + " : " + emp5Designation);
            



            foreach (Object obj in al)
            {
                empId++;
                Console.WriteLine("Employee ID : {0} ", empId);

                Console.WriteLine(obj);

            }
            Console.ReadKey();
            
        }

    }
}
