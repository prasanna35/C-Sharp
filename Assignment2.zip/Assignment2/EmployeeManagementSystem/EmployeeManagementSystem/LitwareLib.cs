﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    public class LitwareLib
    {
        static void Main(string[] args)
        {
            
            Employee employee = new Employee();

            int empNo;
            string empName;
            double empSalary;

       
            Console.WriteLine("Enter Employee Number : ");
            empNo = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Employee Name : ");
            empName = Console.ReadLine();

            Console.WriteLine("Enter Employee Salary: ");
            empSalary = double.Parse(Console.ReadLine());

           
            employee.SetEmpNo(empNo);
            employee.SetEmpName(empName);
            employee.SetSalary(empSalary);
            employee.calculateSalary(employee);

           
            Console.WriteLine("Emp no:" + employee.GetEmpNo());
            Console.WriteLine("Name:" + employee.GetEmpName());
            Console.WriteLine("Salary :" + employee.GetSalary());
            Console.WriteLine("Gross Salary :" + employee.GetGrossSalary());

            Console.ReadKey();

        }

    }
}
