﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighestStudMarks
{
     public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter no.of Students");
            int n = int.Parse(Console.ReadLine());
            int[] marks = new int[n];
            int max = 0;

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter average marks of Student {0} Marks: ", i+1);
                marks[i] = Convert.ToInt32(Console.ReadLine());
                if (i == 0)
                {
                    max = marks[0];
                }
                else if (max < marks[i])
                {
                    max = marks[i];
                }
            }
            Console.WriteLine("Highest marks Among of All Students {0}", max);
            Console.ReadLine();
        }
    }
}
