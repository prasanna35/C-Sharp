﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStructure
{
    public class Program
    {
        struct Book
        {

            
            int bookId;
            string title;
            double price;

           
            public void setDetails(int bookId, string title, double price)
            {
                this.bookId = bookId;
                this.title = title;
                this.price = price;
            }

           
            public void display()
            {

                Console.WriteLine("The Book ID is : " + bookId);
                Console.WriteLine("The Book Title is : " + title);
                Console.WriteLine("The Book Price is : " + price);
                Console.WriteLine("The Book Type is : " + bookType.Magazine);
            }

            enum bookType
            {
                Magazine, Novel, ReferenceBook, Miscellaneous

            }

        }

        public static void Main(String[] args)
        {

            int bookId;
            string title;
            double price;

            
            Book book = new Book();

           
            Console.WriteLine("Enter Book ID: ");
            bookId =int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Book Title: ");
            title = Console.ReadLine();

            Console.WriteLine("Enter Book Price : ");
            price = double.Parse(Console.ReadLine());

           
            book.setDetails(bookId, title, price);
            book.display();

            Console.ReadKey();

        }

    }
}
