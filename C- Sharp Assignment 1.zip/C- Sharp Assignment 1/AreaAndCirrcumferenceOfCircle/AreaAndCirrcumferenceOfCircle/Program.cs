﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndCirrcumferenceOfCircle
{
    public class Program
    {
        static void Client(float r)
        {
            float area, circumference, pie = 3.14F;
            area = pie * r * r;
            Console.WriteLine("Area of a Circle {0}", area);
            circumference = 2 * pie * r;
            Console.WriteLine("Circumference of a Circle {0}", circumference);
        }
        static void Main(string[] args)
        {
            float r;
            Console.WriteLine("Enter Radius Of a Circle : ");
            r = float.Parse(Console.ReadLine());
            Client(r);
            
        }
    }
}
