﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
     public class Program
    {
        static void Main(string[] args)
        {
            char choice;
            double num1, num2;
            Console.WriteLine("Enter the operator(+,-,*,/)");
            choice = Console.ReadLine()[0];
            Console.WriteLine("Enter the two numbers");
            num1 = Convert.ToDouble(Console.ReadLine());
            num2 = Convert.ToDouble(Console.ReadLine());

            switch (choice)
            {
                case '+':
                    Console.WriteLine("{0} + {1} ={2}", num1, num2, (num1 + num2));
                    break;

                case '-':
                    Console.WriteLine("{0} - {1} ={2}", num1, num2, (num1 - num2));
                    break;

                case '*':
                    Console.WriteLine("{0} * {1} ={2}", num1, num2, (num1 * num2));
                    break;

                case '/':
           
                        Console.WriteLine("{0} / {1} ={2}", num1, num2, (num1 / num2));
                    break;
                default:
                    Console.WriteLine("{0} is an invalid operator", choice);
                    break;
            }
            Console.WriteLine("Enter any key to exit");
            Console.ReadKey();


        }
    }
}
