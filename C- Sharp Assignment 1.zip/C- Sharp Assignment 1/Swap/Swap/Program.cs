﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swap
{
    public class Program
    {
        static void Swap(int num1, int num2)
        {
            int temp;
            temp = num1;
            num1 = num2;
            num2 = temp;
            Console.WriteLine("After swaping numbers are {0} and {1}", num1, num2);
        }
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Enter  First Numer To Swap");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd Number To swap ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Before Swaping numers are {0} and {1}", num1, num2);
            Swap(num1, num2);
            Console.ReadLine();
        }
    }
}
