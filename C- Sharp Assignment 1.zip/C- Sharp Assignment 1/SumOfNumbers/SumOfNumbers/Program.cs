﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfNumbers
{
     public class Program
    {
        static void Client(int[] integer)
        {
            int sum = 0;
            for (int i = 0; i < integer.Length; i++)
                sum += integer[i];
            Console.WriteLine("Sum of all the integers {0}", sum);
        }
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the size of Integers");
            int n= int.Parse(Console.ReadLine());
            int[] integer = new int[n];
            Console.WriteLine("Enter the {0} Integers",n);
            for (int i = 0; i < integer.Length; i++)
            {
                integer[i] = Convert.ToInt32(Console.ReadLine());
            }
            Client(integer);
            Console.ReadLine();
        }
    }
}
